const btnEls = document.querySelectorAll('.btn')
// ...
btnEl.addEventListener('click', () => {
  btnEl.classList.add('loading')  
})